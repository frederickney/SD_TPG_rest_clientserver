__author__ = 'Frederick NEY et Stephane OVERLEN'


class Cmd(object):
    HOST = None
    PORT = None

    @staticmethod
    def parser(args):
        return

