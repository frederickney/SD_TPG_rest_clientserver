__author__ = 'Frederick NEY & Stephane Overlen'


AUTH_KEY = "hZELIENF7EHRoHL2rY7i"
STOP_TIME = "3h30"
RUNNING_TIME = "4h15"
TPG_SERVER = "prod.ivtr-od.tpg.ch"
SERVER_VERSION = "v1"
KEY = "key"