define({
  "name": "TPG rest server - client",
  "version": "1.0.1",
  "description": "TPG rest server - client writen in python by Stephane OVERLEN and Frederick NEY",
  "title": "HEPIA",
  "url": "http://domainName",
  "header": {
    "title": "TPG rest project"
  },
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-11-15T05:22:45.658Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
