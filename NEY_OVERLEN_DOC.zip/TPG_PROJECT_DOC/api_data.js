define({ "api": [
  {
    "type": "get",
    "url": "/list/stop/around500Meter?id=ID&hash=HASH&latitude=LAT&longitude=LONG",
    "title": "get_stop_localisation()",
    "name": "get_stop_localisation",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          },
          {
            "group": "Parameter",
            "type": "LAT",
            "allowedValues": [
              "float[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of latitude</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stops around 500 meters for a location</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/stop/available?id=ID&hash=HASH",
    "title": "list_available_stop()",
    "name": "list_available_stop",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of available stop</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/list/stop/subscribed/nextDeparture?id=ID&hash=HASH&stopName=STOPNAME&code=CODE",
    "title": "list_next_departure()",
    "name": "list_next_departure",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          },
          {
            "group": "Parameter",
            "type": "STOPNAME",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stop</p>"
          },
          {
            "group": "Parameter",
            "type": "CODE",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "optional",
            "description": "<p>should be 'stopName' or 'stopCode'</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "List",
            "description": "<p>of departure</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/list/stop/subscribed/nextDeparture/handicaped?id=ID&hash=HASH&stopName=STOPCODE&code=CODE",
    "title": "list_next_departure_for_handicaped()",
    "name": "list_next_departure_for_handicaped",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          },
          {
            "group": "Parameter",
            "type": "STOPCODE",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stop</p>"
          },
          {
            "group": "Parameter",
            "type": "CODE",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "optional",
            "description": "<p>should be 'stopName' or 'stopCode'</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "List",
            "description": "<p>of departure with handicapped capabilities</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/list/stop/subscribed?id=ID&hash=HASH",
    "title": "list_stop_subscribed()",
    "name": "list_stop_subscribed",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "string[]",
            "allowedValues": [
              "return"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stop</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/list/stop/subscribe?id=ID&hash=HASH&stopName=STOPCODE",
    "title": "subscribe()",
    "name": "subscribe",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          },
          {
            "group": "Parameter",
            "type": "STOPCODE",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stop</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "error",
            "description": "<p>code</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "get",
    "url": "/list/stop/unsubscribe?stopName=STOPCODE&id=ID&hash=HASH",
    "title": "un_subscribe()",
    "name": "un_subscribe",
    "group": "TPG",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          },
          {
            "group": "Parameter",
            "type": "STOPCODE",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "list",
            "description": "<p>of stop</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "error",
            "description": "<p>code</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "TPG"
  },
  {
    "type": "post",
    "url": "/usr/add",
    "title": "add_user()",
    "name": "add_user",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "USERNAME",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>'s credentials</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "message",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "/usr/del",
    "title": "del_user()",
    "name": "del_user",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "message",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "/usr/signIn",
    "title": "sign_in()",
    "name": "sign_in",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "USERNAME",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>'s credentials</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "message",
            "description": "<p>or session</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "/usr/signOut",
    "title": "sign_out()",
    "name": "sign_out",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "ID",
            "allowedValues": [
              "Integer"
            ],
            "optional": false,
            "field": "user",
            "description": "<p>id</p>"
          },
          {
            "group": "Parameter",
            "type": "HASH",
            "allowedValues": [
              "string"
            ],
            "optional": false,
            "field": "session",
            "description": "<p>hash</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "return",
            "allowedValues": [
              "string[]"
            ],
            "optional": false,
            "field": "message",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "source_doc/doc.py",
    "groupTitle": "User"
  }
] });
